package bg.tu_varna.sit.task4;

public interface Usage {
    boolean isProductable();    
}
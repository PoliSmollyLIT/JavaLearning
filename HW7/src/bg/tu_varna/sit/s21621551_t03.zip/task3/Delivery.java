package bg.tu_varna.sit.task3;

public interface Delivery {
    boolean needsDelivery();
    
}
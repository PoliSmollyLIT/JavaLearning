package bg.tu_varna.sit.task5;

public enum Fragrances {
    LEMON,
    ORANGE,
    KIWI,
    PEACH,
    APRICOT,
    PEAR,
    COLA,
    NONE    
}
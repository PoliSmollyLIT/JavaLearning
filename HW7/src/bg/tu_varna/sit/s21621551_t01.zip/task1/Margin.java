package bg.tu_varna.sit.task1;

public interface Margin {
    double calculateMargin();    
}
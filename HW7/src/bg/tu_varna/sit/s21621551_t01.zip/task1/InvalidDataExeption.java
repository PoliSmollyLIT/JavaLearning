package bg.tu_varna.sit.task1;

public class InvalidDataExeption extends Exception{

    public InvalidDataExeption() {
        super("Въведенеи са грешни стойности");
    }
    
}

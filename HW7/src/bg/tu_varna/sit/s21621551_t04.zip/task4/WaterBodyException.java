package bg.tu_varna.sit.task4;

public class WaterBodyException extends Exception{

    public WaterBodyException(String message) {
        super(message);
    }
    
    
}
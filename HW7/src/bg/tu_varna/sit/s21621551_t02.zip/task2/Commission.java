package bg.tu_varna.sit.task2;

public interface Commission {
    double calculateCommission();    
}
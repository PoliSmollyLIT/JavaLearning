package bg.tu_varna.sit.task5;

public class AlcoholicBeverageException extends Exception{

    public AlcoholicBeverageException(String message) {
        super(message);
    }

    
    
}
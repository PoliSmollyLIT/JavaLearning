package bg.tu_varna.sit.task3;

public enum ItemType {
    FOOD,
    DRINK    
}
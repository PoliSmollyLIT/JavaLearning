package bg.tu_varna.sit.task4;

public enum FishList {
    ESTER,
    CATFISH,
    PERCH,
    TENCH,
    PIRANHA   
}

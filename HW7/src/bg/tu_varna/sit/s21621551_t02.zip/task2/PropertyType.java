package bg.tu_varna.sit.task2;

public enum PropertyType {
    RENT,
    SALE,
    UNDEFINED    
}
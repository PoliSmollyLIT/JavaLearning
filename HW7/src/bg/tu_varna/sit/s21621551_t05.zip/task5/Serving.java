package bg.tu_varna.sit.task5;

public interface Serving {
    void serve(int quantity);    
}
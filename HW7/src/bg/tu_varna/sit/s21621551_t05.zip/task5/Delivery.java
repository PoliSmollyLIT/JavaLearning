package bg.tu_varna.sit.task5;

public interface Delivery {
    boolean needOfDelivery();
    void deliver(int quantityDrinks);
}
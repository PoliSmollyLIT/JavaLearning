package bg.tu_varna.sit.task1;

public enum CoverType {
    HARDCOVER,
    PAPERBACK    
}